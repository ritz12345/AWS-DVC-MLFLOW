from __future__ import annotations

import textwrap

from churn.dvc_meta import lineage_tags, output_hashes, read_lock


def _write_lock(root):
    (root / "dvc.lock").write_text(
        textwrap.dedent(
            """\
            schema: '2.0'
            stages:
              features:
                cmd: python -m churn.features
                outs:
                - path: data/interim/features.parquet
                  md5: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
              split:
                cmd: python -m churn.split
                outs:
                - path: data/processed
                  md5: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.dir
            """
        ),
        encoding="utf-8",
    )


def test_read_lock_missing_is_empty(tmp_path):
    assert read_lock(tmp_path) == {}


def test_output_hashes(tmp_path):
    _write_lock(tmp_path)
    hashes = output_hashes(tmp_path)
    assert hashes["data/interim/features.parquet"].startswith("aaaa")
    assert hashes["data/processed"].endswith(".dir")


def test_lineage_tags_are_mlflow_safe(tmp_path):
    _write_lock(tmp_path)
    tags = lineage_tags(tmp_path)
    assert tags["dvc.data.processed"].startswith("bbbb")
    assert tags["dvc_pipeline_stages"] == "features split"
    assert "git_commit" in tags
    for key, value in tags.items():
        assert all(ch.isalnum() or ch in "_-./ " for ch in key), key
        # SageMaker-managed MLflow rejects model-version tag values outside this set.
        assert all(ch.isalnum() or ch in " _.:/=+-@" for ch in value), (key, value)
