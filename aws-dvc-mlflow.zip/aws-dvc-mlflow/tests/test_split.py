from __future__ import annotations

import pandas as pd
import pytest

from churn.features import build_features
from churn.split import OUTPUTS, balance, label_first, run, three_way_split, write_outputs


@pytest.fixture
def features(raw, params):
    out, _ = build_features(raw, params)
    return out


def test_label_first(features):
    out = label_first(features.drop(columns=["player_id"]), "player_churn")
    assert out.columns[0] == "player_churn"


def test_three_way_split_is_exhaustive_and_disjoint(features, params):
    train, val, test = three_way_split(
        features, "player_churn", train_frac=0.6, val_frac=0.2, random_state=7, stratify=True
    )
    assert len(train) + len(val) + len(test) == len(features)
    ids = [set(frame["player_id"]) for frame in (train, val, test)]
    assert not ids[0] & ids[1]
    assert not ids[0] & ids[2]
    assert not ids[1] & ids[2]


def test_three_way_split_rejects_impossible_fractions(features):
    with pytest.raises(ValueError, match="must be < 1.0"):
        three_way_split(
            features, "player_churn", train_frac=0.9, val_frac=0.2, random_state=7, stratify=True
        )


def test_balance_reaches_parity(features):
    balanced = balance(features, "player_churn", 7)
    counts = balanced["player_churn"].value_counts()
    assert counts.nunique() == 1


def test_no_player_leaks_from_train_into_test(features, params):
    """The regression guard for the original workshop's leak.

    Oversampling before the split put duplicate players in both folds. Balancing
    the train fold only must leave train and test id sets disjoint.
    """
    cfg = dict(params)
    frames, summary = run(features, cfg)
    assert summary["balanced_train"] is True
    assert summary["train_rows"] > summary["train_rows_before_balance"]

    # run() drops player_id, so re-derive the folds to compare identities.
    train, _val, test = three_way_split(
        features,
        "player_churn",
        train_frac=cfg["split"]["train_frac"],
        val_frac=cfg["split"]["val_frac"],
        random_state=cfg["split"]["random_state"],
        stratify=True,
    )
    assert not set(balance(train, "player_churn", 7)["player_id"]) & set(test["player_id"])


def test_test_fold_keeps_natural_class_balance(features, params):
    _frames, summary = run(features, params)
    assert summary["train_positive_rate"] == pytest.approx(0.5, abs=0.02)
    # Test must NOT be balanced -- that is the distribution we want to measure on.
    assert summary["test_positive_rate"] < 0.4


def test_outputs_are_headerless_with_label_first(features, params, tmp_path):
    frames, _ = run(features, params)
    write_outputs(frames, tmp_path)
    for filename in OUTPUTS.values():
        assert (tmp_path / filename).exists()
    train = pd.read_csv(tmp_path / "train.csv", header=None)
    assert set(train[0].unique()) <= {0, 1}
    assert len(pd.read_csv(tmp_path / "test_x.csv", header=None).columns) == train.shape[1] - 1


def test_baseline_has_no_label(features, params):
    frames, _ = run(features, params)
    assert frames["baseline"].shape[1] == frames["train"].shape[1] - 1
