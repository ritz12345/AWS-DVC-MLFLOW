from __future__ import annotations

import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def params() -> dict:
    return {
        "project": {"target_col": "player_churn", "id_col": "player_id"},
        "features": {
            "keep_cols": ["session_count", "player_lifetime", "spread", "player_type"],
            "fill_zero_cols": ["spread"],
            "one_hot_cols": ["player_type"],
        },
        "split": {
            "train_frac": 0.6,
            "val_frac": 0.2,
            "random_state": 7,
            "stratify": True,
            "balance_train": True,
        },
    }


@pytest.fixture
def raw() -> pd.DataFrame:
    rng = np.random.default_rng(0)
    n = 200
    return pd.DataFrame(
        {
            "player_id": [f"p{i:04d}" for i in range(n)],
            "session_count": rng.integers(1, 20, n),
            "player_lifetime": rng.normal(5e5, 1e5, n),
            "spread": np.where(rng.random(n) < 0.3, np.nan, rng.normal(100, 10, n)),
            "player_type": rng.choice(["casual", "hardcore"], n),
            # 20% positives, so balancing is observable
            "player_churn": rng.random(n) < 0.2,
            "unused_column": rng.random(n),
        }
    )
