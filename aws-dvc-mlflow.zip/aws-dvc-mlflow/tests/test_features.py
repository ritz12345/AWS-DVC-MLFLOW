from __future__ import annotations

import pytest

from churn.features import build_features, fill_zero, one_hot, select_columns


def test_select_columns_keeps_label_and_id(raw, params):
    out = select_columns(raw, params["features"]["keep_cols"], ["player_churn", "player_id"])
    assert "player_churn" in out.columns
    assert "player_id" in out.columns
    assert "unused_column" not in out.columns


def test_select_columns_raises_on_renamed_column(raw, params):
    with pytest.raises(KeyError, match="stale"):
        select_columns(raw, [*params["features"]["keep_cols"], "gone_missing"], [])


def test_fill_zero_reports_counts(raw):
    filled, counts = fill_zero(raw, ["spread"])
    assert filled["spread"].isna().sum() == 0
    assert counts["spread"] == int(raw["spread"].isna().sum())


def test_one_hot_expands_and_is_integer(raw):
    out = one_hot(raw, ["player_type"])
    assert "player_type" not in out.columns
    assert {"player_type_casual", "player_type_hardcore"} <= set(out.columns)
    assert out["player_type_casual"].dtype.kind in "iu"


def test_build_features_casts_label_to_int(raw, params):
    out, summary = build_features(raw, params)
    assert out["player_churn"].dtype == "int64"
    assert summary["n_rows"] == len(raw)
    assert not summary["columns_with_nan"]


def test_build_features_does_not_balance(raw, params):
    """Resampling must happen after the split, not here."""
    out, summary = build_features(raw, params)
    assert len(out) == len(raw)
    assert summary["positive_rate"] == pytest.approx(raw["player_churn"].mean())
