# How DVC data versions are tracked in MLflow

This document explains, step by step, how every MLflow training run and every
registered model version in `churn-mlops` is linked to the exact dataset it was
trained on, and how you get that dataset back later.

**In short:** DVC versions the data, MLflow tracks the runs. The link between
them is a set of MLflow **tags** holding the git commit and the DVC content
hashes from `dvc.lock`. The tags are written by `src/churn/dvc_meta.py`.

---

## 1. Who owns what

| Concern | Owner | Where it lives |
|---|---|---|
| Raw data bytes | DVC | S3 DVC remote (content-addressed), pointer `data/raw/player_churn.csv.dvc` in git |
| Feature + split pipeline | DVC | `dvc.yaml` (definition), `dvc.lock` (hashes of what was produced) |
| Training/eval params, metrics, model artifact | MLflow | SageMaker MLflow tracking server |
| Code version | git | commit SHA |
| **Link between data and run** | **MLflow tags** | `git_commit`, `dvc_pipeline_stages`, `dvc.*` tags on the run and the model version |

Training and evaluation are deliberately **not** DVC stages (see the header of
`dvc.yaml`). They run as remote SageMaker jobs and MLflow already records their
params and metrics. Making them DVC stages would rewrite `dvc.lock` on every
experiment and leave two competing places that store metrics.

```
 data/raw/player_churn.csv ──(dvc add)──► player_churn.csv.dvc  (md5 pointer, in git)
            │
            ▼  dvc repro
   stage "features"  ──► data/interim/features.parquet
            │
            ▼
   stage "split"     ──► data/processed/{train,validation,test_x,test_y}.csv
            │                     + reports/split_summary.json
            ▼
        dvc.lock  (md5 of every dep and out)  ── committed to git
            │
            │  read by churn.dvc_meta.lineage_tags()
            ▼
   MLflow run tags  ──copied──►  MLflow model version tags
   git_commit, dvc.data.processed, dvc.data.interim.features.parquet, ...
```

---

## 2. Step by step

### Step 1: Version the raw data (`notebooks/01-data-versioning.ipynb`)

1. `dvc init --subdir` creates `.dvc/` inside `churn-mlops/`. `--subdir` is
   needed because this project is a folder inside a larger git repo.
2. `dvc remote add --default s3remote <settings.dvc_remote_url>` points DVC at
   its own S3 prefix (`aws.dvc_remote_prefix` in `params.yaml`), kept separate
   from the plain CSVs that training jobs read.
3. `dvc add data/raw/player_churn.csv`:
   - hashes the file and stores it in the local DVC cache
   - writes the small pointer file `data/raw/player_churn.csv.dvc` (holds the md5)
   - adds the CSV to `data/raw/.gitignore`, so git never stores the data itself
4. `dvc push` uploads the data to S3.
5. `git commit` the `.dvc` pointer, `.dvc/config`, `dvc.yaml`, etc.

Push **before** you commit. If a commit's pointers reference data nobody can
fetch, the commit can't be reproduced.

### Step 2: Run the data pipeline (`dvc repro`, `notebooks/02-pipeline.ipynb`)

`dvc.yaml` defines two stages:

| Stage | Command | Deps | Params | Outs |
|---|---|---|---|---|
| `features` | `python -m churn.features` | `data/raw/player_churn.csv`, `src/churn/features.py` | `features`, `project.target_col`, `project.id_col` | `data/interim/features.parquet` |
| `split` | `python -m churn.split` | `data/interim/features.parquet`, `src/churn/split.py` | `split`, `project.target_col` | `data/processed/` (+ metric `reports/split_summary.json`) |

`dvc repro` runs only the stages whose deps or params have changed, then writes
**`dvc.lock`**, which records the md5 of every dependency and output, for
example:

```yaml
stages:
  features:
    deps:
      - path: data/raw/player_churn.csv
        md5: 1f3c...
    outs:
      - path: data/interim/features.parquet
        md5: 9ab2...
  split:
    outs:
      - path: data/processed
        md5: 77d0....dir      # a directory hash covers every file inside
```

`dvc.lock` is the **single source of truth** for which data version is in the
working tree. Commit it after every `dvc repro` that changes it, and `dvc push`
the outputs.

### Step 3: Build the lineage tags (`src/churn/dvc_meta.py`)

`lineage_tags()` builds a flat `dict[str, str]` from three helpers:

1. **`read_lock()`** loads `dvc.lock` as plain YAML, not through the DVC Python
   API, so it works on any machine that has the lock file, even without the
   cache. If the file doesn't exist it returns `{}`.
2. **`output_hashes()`** loops over every stage's `outs` and maps
   `path -> md5` (falling back to `hash` / `checksum`).
3. **`git_commit()`** runs `git rev-parse HEAD` and adds `-dirty` if
   `git status --porcelain` shows uncommitted changes. It returns `"unknown"`
   if git isn't available.

The resulting tags:

| Tag | Example | Meaning |
|---|---|---|
| `git_commit` | `4d3a1d0e...` or `4d3a1d0e...-dirty` | Code + `dvc.lock` revision |
| `dvc_pipeline_stages` | `features,split` | Stages present in `dvc.lock` |
| `dvc.data.interim.features.parquet` | `9ab2...` | md5 of the feature table |
| `dvc.data.processed` | `77d0....dir` | md5 of the whole split directory |

To build a tag key, `dvc.` is prepended to the output path and `/` is replaced
with `.`.

`describe()` prints a one-line human summary (`git 4d3a1d0e1234 / data.processed=77d0abcd, ...`)
for notebooks and `scripts/local-pipeline.sh`.

### Step 4: Train and tag the run (`src/churn/training.py`)

1. **`stage_training_data()`** checks that `data/processed/train.csv` and
   `validation.csv` exist (otherwise it raises and tells you to run
   `dvc repro` / `dvc pull && dvc checkout`), then copies them to a run-scoped S3
   prefix `.../runs/<timestamp>/input`. The built-in SageMaker XGBoost
   container reads plain CSV from S3. It can't read a DVC remote.
2. Inside `mlflow.start_run(...)`:
   ```python
   mlflow.set_tags(lineage_tags())   # line 129 — written FIRST
   mlflow.set_tag("stage", "train")
   mlflow.log_params({...hyperparameters...})
   mlflow.log_params({"train_data_s3": ..., "validation_data_s3": ..., ...})
   estimator.fit(training_inputs)
   ```
   The lineage tags are set **before** `fit()`. If the SageMaker job fails, the
   run still records which data it was given.
3. The job name, training metrics and model artifact are logged to the same run.

The S3 copies are throwaway. What actually records the training data is the
`dvc.*` tags plus `git_commit`.

### Step 5: Evaluate (`src/churn/evaluation.py`)

Evaluation reads `data/processed/test_x.csv` / `test_y.csv`, the same DVC
output, and **re-opens the training run** (`mlflow.start_run(run_id=run_id)`)
to log `test_auc`, `gate_passed`, the ROC plot and the prediction baseline. It
doesn't add new lineage tags. It uses the training run's tags, so it assumes
the working tree hasn't changed since training.

### Step 6: Register and tag the model version (`src/churn/registry.py`)

1. `mlflow.register_model("runs:/<run_id>/<artifact>", name)` creates a new
   version.
2. Every lineage tag is written onto the **model version** itself:
   ```python
   for key, value in lineage_tags().items():
       client.set_model_version_tag(name, version_number, key, value)
   ```
   This lets you answer "what data is production trained on?" without going
   back to the run.
3. `test_auc` and `gate_passed` from the run are also copied as version tags.
4. An alias is set (`candidate`, `production`, ...).

### Step 7: Trace a model back to its data (`scripts/check-lineage.py`)

```sh
python scripts/check-lineage.py                 # @production
python scripts/check-lineage.py --alias staging
python scripts/check-lineage.py --version 3
```

The script prints the MLflow run id, `git_commit`, every `dvc.*` tag,
`test_auc` / `gate_passed`, and then either:

- the restore recipe:
  ```sh
  git checkout <git_commit>
  dvc checkout        # or `dvc pull` on a fresh machine
  ```
- or a **warning** if the commit ends in `-dirty`, because the data can't be
  restored exactly.

After restoring, you can confirm you have the right bytes: the md5s in the
restored `dvc.lock` should match the `dvc.*` tags on the model version.

---

## 3. The whole loop in one command

`scripts/local-pipeline.sh` (the same steps CI runs):

```sh
dvc repro                                              # Step 2
python -c 'from churn.dvc_meta import describe; print(describe())'   # Step 3 (preview)
python -m churn.training --run-name local-...          # Step 4
python -m churn.evaluation --fail-below-threshold      # Step 5
python -m churn.registry --require-gate --alias candidate   # Step 6 (with --register)
```

---

## 4. Rules for the lineage to be valid

The tags are only useful if the commit they point to actually contains the
matching `dvc.lock`. That means:

1. **Run `dvc repro` before training.** Without `dvc.lock` the run gets no
   `dvc.*` tags, and nothing warns you.
2. **Commit `dvc.lock` (and the code) before training.** Otherwise
   `git_commit` is `-dirty` and `git checkout <sha>` won't bring back that
   `dvc.lock`.
3. **`dvc push` before `git commit`**, so the hashes can be fetched from S3.
4. **Don't change data between training and registration** (see gap 3 below).

---

## 5. Current state and known gaps

As of 2026-10-28:

1. **DVC isn't initialised yet.** There's no `.dvc/` directory, no
   `data/raw/player_churn.csv.dvc` pointer and no `dvc.lock`. Notebook 01 and
   `dvc repro` haven't been run, so a training run today would get only
   `git_commit` and an empty `dvc_pipeline_stages`.
2. **The project isn't committed to git.** `churn-mlops/` is untracked, so
   `git_commit` resolves to the parent repo's HEAD with `-dirty`, a commit
   that doesn't contain this code or any `dvc.lock`.
3. **The registry recomputes lineage instead of copying it.**
   `registry.py` calls `lineage_tags()` against the *current* working tree at
   registration time, not the tags of the run being registered. If data or the
   commit changed after training, the model version is tagged with the wrong
   lineage. Fix: copy the `git_commit`, `dvc_pipeline_stages` and `dvc.*` tags
   from `client.get_run(run_id).data.tags`.
4. **A missing `dvc.lock` fails silently.** `read_lock()` returns `{}`.
   Consider raising (or at least warning) in `training.train()` when there are
   no `dvc.*` tags, and refusing to train from a `-dirty` tree in CI.
5. **The raw-data hash isn't tagged directly.** Only stage *outputs* are
   tagged. This is fine in practice, because `data/processed` and
   `features.parquet` depend on the raw file and their hashes change whenever
   it does. The raw md5 is also in `dvc.lock` under `features.deps`.
