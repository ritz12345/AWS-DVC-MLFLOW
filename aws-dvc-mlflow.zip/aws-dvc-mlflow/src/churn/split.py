"""DVC stage 2: feature table -> train / validation / test CSVs.

The ordering here is the one methodological fix over the original workshop.

The workshop oversampled the minority class in notebook 01, ingested the
duplicated rows into Feature Store, and only split in notebook 02. Copies of the
same player therefore landed in both train and test, so the reported AUC was
optimistic by an unknown margin.

Here: stratified split first, then oversample the TRAIN fold only. Validation
and test keep the real-world class balance, which is what you want to measure
against.

Outputs are headerless CSV with the label in column 0 -- the SageMaker built-in
XGBoost contract.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.utils import resample

from churn.config import load_params

# Files this stage produces, by logical name.
OUTPUTS = {
    "train": "train.csv",
    "validation": "validation.csv",
    "test_x": "test_x.csv",
    "test_y": "test_y.csv",
    "baseline": "baseline.csv",
}


def label_first(df: pd.DataFrame, target: str) -> pd.DataFrame:
    """Move the label to column 0, as the XGBoost CSV contract requires."""
    return pd.concat([df[target], df.drop(columns=[target])], axis=1)


def three_way_split(
    df: pd.DataFrame,
    target: str,
    *,
    train_frac: float,
    val_frac: float,
    random_state: int,
    stratify: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Stratified train/validation/test split."""
    test_frac = 1.0 - train_frac - val_frac
    if test_frac <= 0:
        raise ValueError(
            f"train_frac + val_frac must be < 1.0 (got {train_frac} + {val_frac})"
        )

    strat = df[target] if stratify else None
    train, rest = train_test_split(
        df,
        train_size=train_frac,
        random_state=random_state,
        stratify=strat,
    )
    # val_frac and test_frac are fractions of the whole, so rescale for the
    # second cut.
    rel_val = val_frac / (val_frac + test_frac)
    strat_rest = rest[target] if stratify else None
    validation, test = train_test_split(
        rest,
        train_size=rel_val,
        random_state=random_state,
        stratify=strat_rest,
    )
    return train, validation, test


def balance(df: pd.DataFrame, target: str, random_state: int) -> pd.DataFrame:
    """Oversample the minority class with replacement up to parity."""
    counts = df[target].value_counts()
    if len(counts) < 2:
        return df.copy()

    majority_label = counts.idxmax()
    major = df[df[target] == majority_label]
    frames = [major]
    for label, _ in counts.items():
        if label == majority_label:
            continue
        minority = df[df[target] == label]
        frames.append(
            resample(
                minority,
                replace=True,
                n_samples=len(major),
                random_state=random_state,
            )
        )
    out = pd.concat(frames)
    return out.sample(frac=1, random_state=random_state).reset_index(drop=True)


def run(df: pd.DataFrame, params: dict[str, Any]) -> tuple[dict[str, pd.DataFrame], dict[str, Any]]:
    cfg = params["split"]
    target = params["project"]["target_col"]
    id_col = params["project"]["id_col"]
    seed = int(cfg["random_state"])

    # The player id is lineage, not signal.
    model_data = df.drop(columns=[c for c in [id_col] if c in df.columns])
    model_data = label_first(model_data, target)

    train, validation, test = three_way_split(
        model_data,
        target,
        train_frac=float(cfg["train_frac"]),
        val_frac=float(cfg["val_frac"]),
        random_state=seed,
        stratify=bool(cfg.get("stratify", True)),
    )

    raw_train_rows = len(train)
    if cfg.get("balance_train", True):
        train = balance(train, target, seed)

    frames = {
        "train": train,
        "validation": validation,
        "test_x": test.drop(columns=[target]),
        "test_y": test[[target]],
        # Unbalanced, label-free copy of everything, kept for model-monitoring
        # baselines.
        "baseline": model_data.drop(columns=[target]),
    }

    summary = {
        "n_rows_total": int(len(model_data)),
        "n_features": int(model_data.shape[1] - 1),
        "train_rows_before_balance": int(raw_train_rows),
        "train_rows": int(len(train)),
        "validation_rows": int(len(validation)),
        "test_rows": int(len(test)),
        "train_positive_rate": float(train[target].mean()),
        "validation_positive_rate": float(validation[target].mean()),
        "test_positive_rate": float(test[target].mean()),
        "balanced_train": bool(cfg.get("balance_train", True)),
        "random_state": seed,
    }
    return frames, summary


def write_outputs(frames: dict[str, pd.DataFrame], outdir: Path) -> dict[str, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    written: dict[str, Path] = {}
    for name, filename in OUTPUTS.items():
        path = outdir / filename
        # Headerless: the built-in XGBoost container expects no header row.
        frames[name].to_csv(path, index=False, header=False)
        written[name] = path
    return written


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Split the churn feature table.")
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--params", type=Path, default=None)
    ap.add_argument("--summary", type=Path, default=Path("reports/split_summary.json"))
    args = ap.parse_args(argv)

    params = load_params(args.params)
    df = pd.read_parquet(args.input)
    frames, summary = run(df, params)
    write_outputs(frames, args.outdir)

    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(
        "split: train={train_rows} (from {train_rows_before_balance}) "
        "val={validation_rows} test={test_rows}; "
        "test positive rate {test_positive_rate:.3f}".format(**summary)
    )
    assert np.isfinite(summary["test_positive_rate"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
