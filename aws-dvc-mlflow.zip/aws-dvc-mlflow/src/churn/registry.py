"""Registration: MLflow Model Registry as source of truth, mirrored into SageMaker.

How the two registries relate
-----------------------------
The managed MLflow server is created with ``AutomaticModelRegistration=True``.
When you register a model version in MLflow, SageMaker mirrors it into the
SageMaker Model Registry as a model package, in a package group named after the
MLflow registered model. That is what keeps the SageMaker deploy path, Model
Cards and the Studio registry UI working while you only ever interact with
MLflow.

Two consequences worth knowing:

* The mirror is asynchronous. :func:`wait_for_mirrored_package` polls for it.
* The mirror can be absent (older server, feature disabled, transient failure).
  Deployment therefore has a documented fallback that builds the SageMaker model
  straight from the MLflow artifact -- see :mod:`churn.deployment`.

Stage is expressed with MLflow **aliases**, not the deprecated stages API:
``@candidate`` after registration, ``@staging`` and ``@production`` as it is
promoted.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import mlflow
from mlflow.tracking import MlflowClient

from churn.aws import boto_session
from churn.config import Settings, load_params
from churn.dvc_meta import lineage_tags

ALIAS_CANDIDATE = "candidate"
ALIAS_STAGING = "staging"
ALIAS_PRODUCTION = "production"


@dataclass
class RegisteredModel:
    name: str
    version: str
    run_id: str
    model_uri: str
    sagemaker_model_package_arn: str | None = None


def register(
    *,
    run_id: str,
    settings: Settings | None = None,
    params: dict[str, Any] | None = None,
    artifact_name: str = "model",
    alias: str = ALIAS_CANDIDATE,
    description: str | None = None,
    wait_for_mirror: bool = True,
) -> RegisteredModel:
    """Register the model logged in ``run_id`` and tag it with its lineage."""
    params = params or load_params()
    settings = settings or Settings.load(params, require_role=False)
    name = params["project"]["registered_model_name"]

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    client = MlflowClient()

    model_uri = f"runs:/{run_id}/{artifact_name}"
    version = mlflow.register_model(model_uri=model_uri, name=name)
    version_number = str(version.version)

    # Carry the dataset lineage onto the model version itself, so you can answer
    # "what data is production trained on?" without walking back to the run.
    run = client.get_run(run_id)
    for key, value in lineage_tags().items():
        client.set_model_version_tag(name, version_number, key, value)
    for key in ("test_auc", "gate_passed"):
        if key in run.data.metrics:
            client.set_model_version_tag(name, version_number, key, str(run.data.metrics[key]))

    if description:
        client.update_model_version(name, version_number, description=description)

    client.set_registered_model_alias(name, alias, version_number)

    package_arn = None
    if wait_for_mirror:
        package_arn = wait_for_mirrored_package(
            name, version_number, settings.region, timeout=300
        )

    return RegisteredModel(
        name=name,
        version=version_number,
        run_id=run_id,
        model_uri=f"models:/{name}/{version_number}",
        sagemaker_model_package_arn=package_arn,
    )


def resolve_alias(
    alias: str,
    *,
    settings: Settings | None = None,
    params: dict[str, Any] | None = None,
) -> RegisteredModel:
    """Look up whichever model version currently holds ``alias``."""
    params = params or load_params()
    settings = settings or Settings.load(params, require_role=False)
    name = params["project"]["registered_model_name"]

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    client = MlflowClient()
    version = client.get_model_version_by_alias(name, alias)
    return RegisteredModel(
        name=name,
        version=str(version.version),
        run_id=version.run_id,
        model_uri=f"models:/{name}@{alias}",
        sagemaker_model_package_arn=find_mirrored_package(
            name, str(version.version), settings.region
        ),
    )


def promote(
    *,
    version: str,
    alias: str,
    settings: Settings | None = None,
    params: dict[str, Any] | None = None,
    approve_in_sagemaker: bool = True,
) -> RegisteredModel:
    """Move ``alias`` to ``version``.

    When promoting to production we also flip the mirrored SageMaker model
    package to ``Approved``, so anything reading the SageMaker registry (Studio,
    monitoring, another team's tooling) agrees with MLflow.
    """
    params = params or load_params()
    settings = settings or Settings.load(params, require_role=False)
    name = params["project"]["registered_model_name"]

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    client = MlflowClient()
    client.set_registered_model_alias(name, alias, version)

    package_arn = find_mirrored_package(name, version, settings.region)
    if approve_in_sagemaker and package_arn and alias == ALIAS_PRODUCTION:
        set_package_approval(package_arn, "Approved", settings.region)

    return RegisteredModel(
        name=name,
        version=version,
        run_id=client.get_model_version(name, version).run_id,
        model_uri=f"models:/{name}/{version}",
        sagemaker_model_package_arn=package_arn,
    )


# --------------------------------------------------------------------------
# SageMaker Model Registry mirror
# --------------------------------------------------------------------------


def find_mirrored_package(model_name: str, version: str, region: str) -> str | None:
    """Find the SageMaker model package mirroring an MLflow model version.

    Matches on the MLflow metadata SageMaker attaches to the mirrored package,
    then falls back to positional matching (MLflow version N -> package version
    N), which is how the mirror behaves for a group it created itself.
    """
    sm = boto_session(region).client("sagemaker")
    try:
        packages = sm.list_model_packages(
            ModelPackageGroupName=model_name,
            SortBy="CreationTime",
            SortOrder="Ascending",
            MaxResults=100,
        )["ModelPackageSummaryList"]
    except sm.exceptions.ClientError:
        return None
    if not packages:
        return None

    for pkg in packages:
        arn = pkg["ModelPackageArn"]
        detail = sm.describe_model_package(ModelPackageName=arn)
        meta = detail.get("CustomerMetadataProperties") or {}
        if str(meta.get("mlflow_model_version") or meta.get("ModelVersion") or "") == str(version):
            return arn
        tags = {t["Key"]: t["Value"] for t in sm.list_tags(ResourceArn=arn).get("Tags", [])}
        if str(tags.get("mlflow_model_version", "")) == str(version):
            return arn

    for pkg in packages:
        if str(pkg.get("ModelPackageVersion")) == str(version):
            return pkg["ModelPackageArn"]
    return None


def wait_for_mirrored_package(
    model_name: str, version: str, region: str, *, timeout: int = 300
) -> str | None:
    """Poll for the mirror. Returns ``None`` on timeout rather than raising --
    a missing mirror is recoverable, see :mod:`churn.deployment`."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        arn = find_mirrored_package(model_name, version, region)
        if arn:
            return arn
        time.sleep(15)
    print(
        f"  (no SageMaker model package mirrored for {model_name} v{version} after {timeout}s; "
        "deployment will fall back to the MLflow artifact)"
    )
    return None


def set_package_approval(package_arn: str, status: str, region: str) -> None:
    boto_session(region).client("sagemaker").update_model_package(
        ModelPackageArn=package_arn, ModelApprovalStatus=status
    )


def main(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    ap = argparse.ArgumentParser(description="Register an evaluated model in MLflow.")
    ap.add_argument("--evaluation", type=Path, default=Path("reports/evaluation.json"))
    ap.add_argument("--run-id", default=None)
    ap.add_argument("--alias", default=ALIAS_CANDIDATE)
    ap.add_argument("--description", default=None)
    ap.add_argument("--output", type=Path, default=Path("reports/registered_model.json"))
    ap.add_argument(
        "--require-gate",
        action="store_true",
        help="Refuse to register unless the evaluation passed the AUC gate.",
    )
    args = ap.parse_args(argv)

    run_id = args.run_id
    evaluation: dict[str, Any] = {}
    if args.evaluation.exists():
        evaluation = json.loads(args.evaluation.read_text(encoding="utf-8"))
        run_id = run_id or evaluation.get("run_id")
    if not run_id:
        ap.error("need --run-id or an existing --evaluation file")

    if args.require_gate and not evaluation.get("passed", False):
        auc_value = (evaluation.get("metrics") or {}).get("test_auc")
        print(f"refusing to register: test AUC {auc_value} did not clear the gate")
        return 1

    description = args.description
    if description is None and evaluation:
        auc_value = (evaluation.get("metrics") or {}).get("test_auc")
        description = f"test AUC {auc_value:.4f}" if auc_value is not None else None

    model = register(run_id=run_id, alias=args.alias, description=description)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "name": model.name,
                "version": model.version,
                "run_id": model.run_id,
                "model_uri": model.model_uri,
                "sagemaker_model_package_arn": model.sagemaker_model_package_arn,
                "alias": args.alias,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"registered: {model.name} v{model.version} @{args.alias}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
