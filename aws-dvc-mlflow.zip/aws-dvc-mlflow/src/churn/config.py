"""Configuration loading.

Two layers, deliberately separate:

* ``params.yaml`` holds everything that affects the *model* (feature list,
  split ratios, hyperparameters, gates). DVC hashes it, so it belongs in git.
* :class:`Settings` holds everything that affects the *environment* (region,
  bucket, MLflow server, IAM role). These come from env vars because they differ
  between a laptop, Studio and a GitHub Actions runner -- and because an account
  ID does not belong in a committed file.

Nothing in this project asks you to paste an ARN into a notebook cell.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

_THIS_DIR = Path(__file__).resolve().parent
# src/churn -> src -> <project root>
_DEFAULT_ROOT = _THIS_DIR.parents[1]


def project_root() -> Path:
    """Root of the churn-mlops project (where params.yaml and dvc.yaml live)."""
    env = os.getenv("CHURN_PROJECT_ROOT")
    return Path(env).expanduser().resolve() if env else _DEFAULT_ROOT


@lru_cache(maxsize=8)
def _load_yaml(path: str) -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def load_params(path: str | Path | None = None) -> dict[str, Any]:
    """Read ``params.yaml``. Cached per path."""
    target = Path(path) if path else project_root() / "params.yaml"
    return _load_yaml(str(target.resolve()))


@dataclass(frozen=True)
class Settings:
    """Environment-specific configuration."""

    region: str
    bucket: str
    bucket_prefix: str
    dvc_remote_prefix: str
    mlflow_tracking_uri: str
    sagemaker_role: str

    @property
    def s3_base(self) -> str:
        return f"s3://{self.bucket}/{self.bucket_prefix}"

    @property
    def dvc_remote_url(self) -> str:
        return f"s3://{self.bucket}/{self.dvc_remote_prefix}"

    @classmethod
    def load(cls, params: dict[str, Any] | None = None, *, require_role: bool = True) -> Settings:
        """Build settings from env vars, falling back to params.yaml and the
        SageMaker defaults.

        Recognised env vars:
            AWS_DEFAULT_REGION / CHURN_AWS_REGION
            CHURN_S3_BUCKET
            MLFLOW_TRACKING_URI      (the managed-MLflow ARN)
            CHURN_SAGEMAKER_ROLE     (execution role ARN)
        """
        params = params or load_params()
        aws = params.get("aws", {})

        region = (
            os.getenv("CHURN_AWS_REGION")
            or os.getenv("AWS_DEFAULT_REGION")
            or os.getenv("AWS_REGION")
            or aws.get("region", "us-east-1")
        )

        bucket = os.getenv("CHURN_S3_BUCKET") or ""
        role = os.getenv("CHURN_SAGEMAKER_ROLE") or ""

        if not bucket or (require_role and not role):
            # Only import sagemaker when we actually have to -- it is slow and
            # the pure-pandas DVC stages must not need it.
            import boto3
            import sagemaker

            session = sagemaker.Session(boto_session=boto3.Session(region_name=region))
            bucket = bucket or session.default_bucket()
            if require_role and not role:
                role = _resolve_role(session)

        return cls(
            region=region,
            bucket=bucket,
            bucket_prefix=aws.get("bucket_prefix", "player-churn/dvc-mlflow"),
            dvc_remote_prefix=aws.get("dvc_remote_prefix", "player-churn/dvc-store"),
            mlflow_tracking_uri=os.getenv("MLFLOW_TRACKING_URI", ""),
            sagemaker_role=role,
        )


def _resolve_role(session: Any) -> str:
    """Execution role, whether we are inside Studio or on a CI runner."""
    import sagemaker

    try:
        return sagemaker.get_execution_role(sagemaker_session=session)
    except Exception as exc:  # noqa: BLE001 - not running in Studio
        raise RuntimeError(
            "Could not resolve a SageMaker execution role. Set CHURN_SAGEMAKER_ROLE "
            "to the ARN of the role SageMaker jobs should assume."
        ) from exc
