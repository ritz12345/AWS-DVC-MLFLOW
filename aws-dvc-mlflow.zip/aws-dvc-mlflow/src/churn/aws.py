"""Thin AWS helpers: sessions, the MLflow tracking server, S3 staging."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import boto3
import sagemaker


def boto_session(region: str) -> boto3.Session:
    return boto3.Session(region_name=region)


def sagemaker_session(region: str) -> sagemaker.Session:
    return sagemaker.Session(boto_session=boto_session(region))


# --------------------------------------------------------------------------
# Managed MLflow tracking server
# --------------------------------------------------------------------------


def find_tracking_server(region: str) -> tuple[str | None, str | None]:
    """Return ``(arn, name)`` of a usable managed-MLflow server, or ``(None, None)``.

    Prefers a server already ``Created``; falls back to one still ``Creating``
    so repeated runs do not pile up servers.
    """
    sm = boto_session(region).client("sagemaker")
    for status in ("Created", "Creating"):
        summaries = sm.list_mlflow_tracking_servers(TrackingServerStatus=status)[
            "TrackingServerSummaries"
        ]
        if summaries:
            s = summaries[0]
            return s["TrackingServerArn"], s["TrackingServerName"]
    return None, None


def ensure_tracking_server(
    region: str,
    bucket: str,
    role_arn: str,
    *,
    name: str | None = None,
    wait: bool = False,
) -> tuple[str, str]:
    """Find an MLflow server or create one. Returns ``(arn, name)``.

    ``AutomaticModelRegistration=True`` is what mirrors MLflow-registered models
    into the SageMaker Model Registry, which is how the deploy path keeps
    working. Do not turn it off.
    """
    arn, found_name = find_tracking_server(region)
    if arn:
        return arn, found_name  # type: ignore[return-value]

    sm = boto_session(region).client("sagemaker")
    ts = time.strftime("%d-%H-%M-%S", time.gmtime())
    server_name = name or f"mlflow-churn-{ts}"
    response = sm.create_mlflow_tracking_server(
        TrackingServerName=server_name,
        ArtifactStoreUri=f"s3://{bucket}/mlflow/{server_name}",
        RoleArn=role_arn,
        AutomaticModelRegistration=True,
    )
    arn = response["TrackingServerArn"]
    if wait:
        wait_for_tracking_server(region, server_name)
    return arn, server_name


def wait_for_tracking_server(region: str, name: str, *, timeout: int = 1800) -> str:
    """Block until the server reports ``Created``. Returns the final status."""
    sm = boto_session(region).client("sagemaker")
    deadline = time.time() + timeout
    while time.time() < deadline:
        status = sm.describe_mlflow_tracking_server(TrackingServerName=name)["TrackingServerStatus"]
        if status == "Created":
            return status
        if status in {"CreateFailed", "DeleteFailed", "Deleting"}:
            raise RuntimeError(f"MLflow server {name} is in state {status}")
        print(f"  MLflow server {name}: {status}")
        time.sleep(30)
    raise TimeoutError(f"MLflow server {name} did not become Created within {timeout}s")


# --------------------------------------------------------------------------
# S3 staging
#
# DVC stores data content-addressed in its own remote. SageMaker training jobs
# need plain CSV at a readable prefix, so we copy the materialised working-tree
# files up under a run-scoped prefix. The DVC hash travels with the MLflow run,
# so these copies are disposable.
# --------------------------------------------------------------------------


def upload_file(local: Path, bucket: str, key: str, region: str) -> str:
    boto_session(region).client("s3").upload_file(str(local), bucket, key)
    return f"s3://{bucket}/{key}"


def upload_dataset(
    files: dict[str, Path],
    bucket: str,
    prefix: str,
    region: str,
) -> dict[str, str]:
    """Upload ``{logical_name: local_path}`` under ``prefix``; return S3 URIs."""
    s3 = boto_session(region).client("s3")
    uris: dict[str, str] = {}
    for name, path in files.items():
        key = f"{prefix.rstrip('/')}/{name}/{path.name}"
        s3.upload_file(str(path), bucket, key)
        uris[name] = f"s3://{bucket}/{key}"
    return uris


def parse_s3_uri(uri: str) -> tuple[str, str]:
    if not uri.startswith("s3://"):
        raise ValueError(f"Not an S3 URI: {uri}")
    bucket, _, key = uri[len("s3://") :].partition("/")
    return bucket, key


def download_file(uri: str, local: Path, region: str) -> Path:
    bucket, key = parse_s3_uri(uri)
    local.parent.mkdir(parents=True, exist_ok=True)
    boto_session(region).client("s3").download_file(bucket, key, str(local))
    return local


def put_json(obj: Any, uri: str, region: str) -> str:
    import json

    bucket, key = parse_s3_uri(uri)
    boto_session(region).client("s3").put_object(
        Bucket=bucket, Key=key, Body=json.dumps(obj, indent=2).encode("utf-8")
    )
    return uri
