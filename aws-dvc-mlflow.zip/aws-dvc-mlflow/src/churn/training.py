"""Training: a SageMaker XGBoost job, tracked in MLflow, pinned to a DVC revision.

The data flow is worth being explicit about, because it is the one place the two
versioning systems meet:

1. ``dvc repro`` (or ``dvc checkout``) materialises ``data/processed/*.csv`` in
   the working tree.
2. We copy train+validation to a run-scoped S3 prefix, because the built-in
   XGBoost container reads plain CSV from S3, not a DVC remote.
3. The MLflow run records the hyperparameters, the job name, the S3 input URIs
   AND the DVC content hashes from ``dvc.lock``.

So the S3 copies are throwaway; ``dvc.lock`` + the git commit are the real
record of what the model was trained on.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import mlflow
import sagemaker
from sagemaker.inputs import TrainingInput

from churn.aws import sagemaker_session, upload_dataset
from churn.config import Settings, load_params
from churn.dvc_meta import lineage_tags
from churn.models import load_booster, log_booster


@dataclass
class TrainingResult:
    run_id: str
    run_name: str
    training_job_name: str
    model_data: str
    """S3 URI of model.tar.gz."""
    metrics: dict[str, float] = field(default_factory=dict)
    data_uris: dict[str, str] = field(default_factory=dict)


def xgboost_image(region: str, version: str) -> str:
    return sagemaker.image_uris.retrieve("xgboost", region=region, version=version)


def build_estimator(
    settings: Settings,
    params: dict[str, Any],
    output_s3_url: str,
    session: sagemaker.Session,
    base_job_name: str,
) -> sagemaker.estimator.Estimator:
    cfg = params["train"]
    estimator = sagemaker.estimator.Estimator(
        image_uri=xgboost_image(settings.region, cfg["xgboost_version"]),
        role=settings.sagemaker_role,
        instance_type=cfg["instance_type"],
        instance_count=int(cfg.get("instance_count", 1)),
        output_path=output_s3_url,
        sagemaker_session=session,
        base_job_name=base_job_name,
        max_run=int(cfg.get("max_run_seconds", 3600)),
    )
    estimator.set_hyperparameters(**cfg["hyperparameters"])
    return estimator


def stage_training_data(
    settings: Settings,
    processed_dir: Path,
    run_prefix: str,
) -> dict[str, str]:
    """Copy the DVC-materialised splits to S3 for the training job."""
    files = {
        "train": processed_dir / "train.csv",
        "validation": processed_dir / "validation.csv",
    }
    for name, path in files.items():
        if not path.exists():
            raise FileNotFoundError(
                f"{path} is missing. Run `dvc repro` (or `dvc pull && dvc checkout`) "
                f"before training; the {name} split is a DVC output."
            )
    return upload_dataset(files, settings.bucket, run_prefix, settings.region)


def train(
    *,
    settings: Settings | None = None,
    params: dict[str, Any] | None = None,
    processed_dir: Path | None = None,
    run_name: str | None = None,
    nested: bool = False,
) -> TrainingResult:
    """Run one tracked training job. Returns the handles the next step needs."""
    params = params or load_params()
    settings = settings or Settings.load(params)
    processed_dir = processed_dir or Path("data/processed")

    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    run_name = run_name or f"train-{stamp}"
    run_prefix = f"{settings.bucket_prefix}/runs/{stamp}/input"
    output_s3_url = f"{settings.s3_base}/runs/{stamp}/output"

    data_uris = stage_training_data(settings, processed_dir, run_prefix)

    session = sagemaker_session(settings.region)
    estimator = build_estimator(
        settings,
        params,
        output_s3_url=output_s3_url,
        session=session,
        base_job_name=f"{params['project']['name']}-xgb",
    )

    training_inputs = {
        channel: TrainingInput(uri, content_type="text/csv")
        for channel, uri in data_uris.items()
    }

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    mlflow.set_experiment(params["project"]["experiment_name"])

    with mlflow.start_run(run_name=run_name, nested=nested) as run:
        # Lineage first: if the job dies we still know what it was fed.
        mlflow.set_tags(lineage_tags())
        mlflow.set_tag("stage", "train")
        mlflow.log_params({f"hp.{k}": v for k, v in params["train"]["hyperparameters"].items()})
        mlflow.log_params(
            {
                "instance_type": params["train"]["instance_type"],
                "xgboost_version": params["train"]["xgboost_version"],
                "train_data_s3": data_uris["train"],
                "validation_data_s3": data_uris["validation"],
            }
        )

        estimator.fit(training_inputs)

        job_name = estimator.latest_training_job.name
        mlflow.log_param("training_job_name", job_name)

        metrics = _job_metrics(estimator)
        if metrics:
            mlflow.log_metrics(metrics)

        booster = load_booster(estimator.model_data, settings.region)
        log_booster(booster, "model")

        return TrainingResult(
            run_id=run.info.run_id,
            run_name=run_name,
            training_job_name=job_name,
            model_data=estimator.model_data,
            metrics=metrics,
            data_uris=data_uris,
        )


def _job_metrics(estimator: sagemaker.estimator.Estimator) -> dict[str, float]:
    """Pull the final value of each emitted training metric.

    ``training_job_analytics`` is flaky right after a job finishes (the metrics
    land in CloudWatch asynchronously), so a failure here must not fail the run.
    """
    try:
        df = estimator.training_job_analytics.dataframe()
    except Exception as exc:  # noqa: BLE001
        print(f"  (training metrics unavailable: {exc})")
        return {}

    metrics: dict[str, float] = {}
    for _, row in df.iterrows():
        key = str(row["metric_name"]).replace(":", "_")
        metrics[key] = float(row["value"])
    return metrics


def main(argv: list[str] | None = None) -> int:
    import argparse
    import json

    ap = argparse.ArgumentParser(description="Run a tracked SageMaker training job.")
    ap.add_argument("--processed-dir", type=Path, default=Path("data/processed"))
    ap.add_argument("--run-name", default=None)
    ap.add_argument(
        "--output",
        type=Path,
        default=Path("reports/train_result.json"),
        help="Where to write run handles, for the next CI step.",
    )
    args = ap.parse_args(argv)

    result = train(processed_dir=args.processed_dir, run_name=args.run_name)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "run_id": result.run_id,
                "training_job_name": result.training_job_name,
                "model_data": result.model_data,
                "metrics": result.metrics,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"trained: run_id={result.run_id} job={result.training_job_name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
