"""Evaluation: score the held-out test split and write the promotion gate verdict.

Metrics and the ROC plot are logged into the SAME MLflow run as the training
job, so one run is one model. The gate decision (`auc >= evaluate.auc_threshold`)
is logged as a metric too, so you can query "which runs passed" in the UI.
"""

from __future__ import annotations

import json
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import mlflow
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import (
    accuracy_score,
    auc,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_curve,
)

from churn.config import Settings, load_params
from churn.models import load_booster


@dataclass
class EvaluationResult:
    run_id: str
    metrics: dict[str, float]
    passed: bool
    threshold: float
    prediction_baseline_s3: str | None = None

    @property
    def auc(self) -> float:
        return self.metrics["test_auc"]


def _roc_plot(fpr: np.ndarray, tpr: np.ndarray, auc_score: float, dest: Path) -> Path:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="chance")
    ax.plot(fpr, tpr, label=f"AUC = {auc_score:.4f}")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("ROC curve (held-out test split)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(dest, dpi=120)
    plt.close(fig)
    return dest


def compute_metrics(y_true: np.ndarray, probability: np.ndarray) -> tuple[dict[str, float], Any]:
    fpr, tpr, _ = roc_curve(y_true, probability)
    auc_score = float(auc(fpr, tpr))
    predicted = (probability >= 0.5).astype(int)
    metrics = {
        "test_auc": auc_score,
        "test_average_precision": float(average_precision_score(y_true, probability)),
        "test_accuracy": float(accuracy_score(y_true, predicted)),
        "test_precision": float(precision_score(y_true, predicted, zero_division=0)),
        "test_recall": float(recall_score(y_true, predicted, zero_division=0)),
        "test_f1": float(f1_score(y_true, predicted, zero_division=0)),
        "test_positive_rate": float(np.mean(y_true)),
        "test_rows": float(len(y_true)),
    }
    return metrics, (fpr, tpr)


def evaluate(
    *,
    run_id: str,
    model_data: str,
    settings: Settings | None = None,
    params: dict[str, Any] | None = None,
    processed_dir: Path | None = None,
) -> EvaluationResult:
    """Score ``model_data`` against the test split and log into ``run_id``."""
    params = params or load_params()
    settings = settings or Settings.load(params, require_role=False)
    processed_dir = processed_dir or Path("data/processed")

    test_x_path = processed_dir / "test_x.csv"
    test_y_path = processed_dir / "test_y.csv"
    for path in (test_x_path, test_y_path):
        if not path.exists():
            raise FileNotFoundError(f"{path} missing. Run `dvc repro` or `dvc checkout` first.")

    X = pd.read_csv(test_x_path, header=None)
    y = pd.read_csv(test_y_path, header=None).to_numpy().squeeze()

    booster = load_booster(model_data, settings.region)
    probability = booster.predict(xgb.DMatrix(X.values))

    metrics, (fpr, tpr) = compute_metrics(y, probability)
    threshold = float(params["evaluate"]["auc_threshold"])
    passed = metrics["test_auc"] >= threshold

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    baseline_uri: str | None = None

    with mlflow.start_run(run_id=run_id):
        mlflow.log_metrics(metrics)
        mlflow.log_metric("gate_auc_threshold", threshold)
        mlflow.log_metric("gate_passed", float(passed))

        with tempfile.TemporaryDirectory() as tmp:
            tmpdir = Path(tmp)
            mlflow.log_artifact(str(_roc_plot(fpr, tpr, metrics["test_auc"], tmpdir / "roc.png")))

            # Prediction baseline, kept for model-quality monitoring later.
            baseline = pd.DataFrame(
                {
                    "prediction": np.round(probability).astype(int),
                    "probability": probability,
                    "label": y.astype(int),
                }
            )
            baseline_local = tmpdir / "prediction_baseline.csv"
            baseline.to_csv(baseline_local, index=False)
            mlflow.log_artifact(str(baseline_local))

            summary_local = tmpdir / "evaluation.json"
            summary_local.write_text(
                json.dumps(
                    {"metrics": metrics, "threshold": threshold, "passed": passed}, indent=2
                ),
                encoding="utf-8",
            )
            mlflow.log_artifact(str(summary_local))

        baseline_uri = mlflow.get_artifact_uri("prediction_baseline.csv")

    return EvaluationResult(
        run_id=run_id,
        metrics=metrics,
        passed=passed,
        threshold=threshold,
        prediction_baseline_s3=baseline_uri,
    )


def main(argv: list[str] | None = None) -> int:
    import argparse

    ap = argparse.ArgumentParser(description="Evaluate a trained model against the test split.")
    ap.add_argument(
        "--train-result",
        type=Path,
        default=Path("reports/train_result.json"),
        help="JSON written by `python -m churn.training`.",
    )
    ap.add_argument("--run-id", default=None)
    ap.add_argument("--model-data", default=None)
    ap.add_argument("--processed-dir", type=Path, default=Path("data/processed"))
    ap.add_argument("--output", type=Path, default=Path("reports/evaluation.json"))
    ap.add_argument(
        "--fail-below-threshold",
        action="store_true",
        help="Exit non-zero if the model misses the gate. Use this in CI.",
    )
    args = ap.parse_args(argv)

    run_id, model_data = args.run_id, args.model_data
    if not (run_id and model_data):
        handles = json.loads(args.train_result.read_text(encoding="utf-8"))
        run_id = run_id or handles["run_id"]
        model_data = model_data or handles["model_data"]

    result = evaluate(run_id=run_id, model_data=model_data, processed_dir=args.processed_dir)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "run_id": result.run_id,
                "model_data": model_data,
                "metrics": result.metrics,
                "threshold": result.threshold,
                "passed": result.passed,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    verdict = "PASS" if result.passed else "FAIL"
    print(f"evaluated: test AUC {result.auc:.4f} vs gate {result.threshold:.2f} -> {verdict}")
    if args.fail_below_threshold and not result.passed:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
