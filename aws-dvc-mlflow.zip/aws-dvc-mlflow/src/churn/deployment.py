"""Deployment: an MLflow alias becomes a SageMaker endpoint.

Resolution order for "what model does @production point at":

1. MLflow alias -> model version (source of truth for *which* model).
2. The mirrored SageMaker model package, if present -> ``ModelPackage.deploy()``.
   Preferred, because the endpoint then references a registry object and keeps
   the usual SageMaker lineage.
3. Fallback: pull the artifact URI off the MLflow run and build a
   ``sagemaker.Model`` around the built-in XGBoost image directly. Used when the
   mirror has not appeared.

Endpoints are named per environment (``<project>-staging`` / ``<project>-prod``)
and updated in place, so repeated deploys do not leak endpoints.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import sagemaker
from sagemaker.model import ModelPackage
from sagemaker.model_monitor import DataCaptureConfig
from sagemaker.predictor import Predictor

from churn.aws import boto_session, sagemaker_session
from churn.config import Settings, load_params
from churn.registry import RegisteredModel, resolve_alias

ENVIRONMENTS = ("staging", "production")


@dataclass
class Deployment:
    endpoint_name: str
    environment: str
    model_name: str
    model_version: str
    source: str
    """``model_package`` or ``mlflow_artifact`` -- which resolution path was used."""


def endpoint_name(params: dict[str, Any], environment: str) -> str:
    suffix = "prod" if environment == "production" else "staging"
    return f"{params['project']['name']}-{suffix}"


def endpoint_exists(name: str, region: str) -> bool:
    sm = boto_session(region).client("sagemaker")
    try:
        sm.describe_endpoint(EndpointName=name)
        return True
    except sm.exceptions.ClientError:
        return False


def _model_from_package(
    model: RegisteredModel, settings: Settings, session: sagemaker.Session
) -> ModelPackage:
    return ModelPackage(
        role=settings.sagemaker_role,
        model_package_arn=model.sagemaker_model_package_arn,
        sagemaker_session=session,
    )


def _model_from_mlflow_artifact(
    model: RegisteredModel,
    settings: Settings,
    params: dict[str, Any],
    session: sagemaker.Session,
) -> sagemaker.Model:
    """Fallback path: wrap the MLflow-stored model artifact in the XGBoost image.

    MLflow stores the booster inside its own artifact layout, so we point at the
    training job's ``model.tar.gz``, which the MLflow run records as the
    ``training_job_name`` param. That tarball is already in the SageMaker
    built-in format, which is what the inference image expects.
    """
    import mlflow
    from mlflow.tracking import MlflowClient

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    run = MlflowClient().get_run(model.run_id)
    job_name = run.data.params.get("training_job_name")
    if not job_name:
        raise RuntimeError(
            f"MLflow run {model.run_id} has no training_job_name param, so the "
            "original model.tar.gz cannot be located. Re-run training with "
            "churn.training, or deploy from the SageMaker model package."
        )
    sm = boto_session(settings.region).client("sagemaker")
    model_data = sm.describe_training_job(TrainingJobName=job_name)["ModelArtifacts"][
        "S3ModelArtifacts"
    ]
    image = sagemaker.image_uris.retrieve(
        "xgboost", region=settings.region, version=params["train"]["xgboost_version"]
    )
    return sagemaker.Model(
        image_uri=image,
        model_data=model_data,
        role=settings.sagemaker_role,
        sagemaker_session=session,
        name=f"{params['project']['name']}-v{model.version}-{int(time.time())}",
    )


def deploy(
    *,
    environment: str,
    alias: str | None = None,
    settings: Settings | None = None,
    params: dict[str, Any] | None = None,
    wait: bool = True,
) -> Deployment:
    """Deploy whichever model version holds ``alias`` to ``environment``."""
    if environment not in ENVIRONMENTS:
        raise ValueError(f"environment must be one of {ENVIRONMENTS}, got {environment!r}")

    params = params or load_params()
    settings = settings or Settings.load(params)
    alias = alias or environment

    model = resolve_alias(alias, settings=settings, params=params)
    session = sagemaker_session(settings.region)
    cfg = params["deploy"][environment]
    name = endpoint_name(params, environment)

    if model.sagemaker_model_package_arn:
        sm_model: Any = _model_from_package(model, settings, session)
        source = "model_package"
    else:
        sm_model = _model_from_mlflow_artifact(model, settings, params, session)
        source = "mlflow_artifact"

    capture = None
    if cfg.get("enable_data_capture"):
        capture = DataCaptureConfig(
            enable_capture=True,
            sampling_percentage=int(cfg.get("data_capture_sampling_percentage", 100)),
            destination_s3_uri=f"{settings.s3_base}/data-capture/{name}",
            capture_options=["REQUEST", "RESPONSE"],
            sagemaker_session=session,
        )

    updating = endpoint_exists(name, settings.region)
    print(
        f"{'Updating' if updating else 'Creating'} endpoint {name} from "
        f"{model.name} v{model.version} (via {source})"
    )

    sm_model.deploy(
        initial_instance_count=int(cfg.get("instance_count", 1)),
        instance_type=cfg["instance_type"],
        endpoint_name=name,
        data_capture_config=capture,
        update_endpoint=updating,
        wait=wait,
    )

    return Deployment(
        endpoint_name=name,
        environment=environment,
        model_name=model.name,
        model_version=model.version,
        source=source,
    )


def predictor(endpoint: str, region: str) -> Predictor:
    return Predictor(
        endpoint_name=endpoint,
        sagemaker_session=sagemaker_session(region),
        serializer=sagemaker.serializers.CSVSerializer(),
        deserializer=sagemaker.deserializers.CSVDeserializer(),
    )


def smoke_test(endpoint: str, region: str, csv_rows: str) -> list[float]:
    """Send a couple of rows and assert the endpoint returns usable scores."""
    raw = predictor(endpoint, region).predict(csv_rows)
    scores = [float(value) for row in raw for value in row if value != ""]
    if not scores:
        raise RuntimeError(f"Endpoint {endpoint} returned no predictions")
    for score in scores:
        if not 0.0 <= score <= 1.0:
            raise RuntimeError(f"Endpoint {endpoint} returned {score}, outside [0, 1]")
    return scores


def main(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    ap = argparse.ArgumentParser(description="Deploy a registered model to an endpoint.")
    ap.add_argument("--environment", choices=ENVIRONMENTS, required=True)
    ap.add_argument("--alias", default=None, help="Defaults to the environment name.")
    ap.add_argument("--processed-dir", type=Path, default=Path("data/processed"))
    ap.add_argument("--skip-smoke-test", action="store_true")
    ap.add_argument("--output", type=Path, default=Path("reports/deployment.json"))
    args = ap.parse_args(argv)

    params = load_params()
    settings = Settings.load(params)
    result = deploy(
        environment=args.environment, alias=args.alias, settings=settings, params=params
    )

    scores: list[float] = []
    if not args.skip_smoke_test:
        test_x = args.processed_dir / "test_x.csv"
        if test_x.exists():
            rows = "\n".join(test_x.read_text(encoding="utf-8").splitlines()[:5])
            scores = smoke_test(result.endpoint_name, settings.region, rows)
            print(f"smoke test ok: {[round(s, 4) for s in scores]}")
        else:
            print(f"  (no {test_x}, skipping smoke test)")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "endpoint_name": result.endpoint_name,
                "environment": result.environment,
                "model_name": result.model_name,
                "model_version": result.model_version,
                "source": result.source,
                "smoke_test_scores": scores,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"deployed: {result.endpoint_name} <- v{result.model_version}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
