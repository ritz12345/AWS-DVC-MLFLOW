"""The join between DVC and MLflow.

DVC knows which bytes went into a model. MLflow knows which run produced it.
Neither is useful without the other, so every training run gets tagged with the
content hashes recorded in ``dvc.lock``, plus the git commit. Given any MLflow
run you can then recover the exact dataset with::

    git checkout <mlflow tag: git_commit>
    dvc checkout

``dvc.lock`` is read as plain YAML rather than through the DVC Python API so
that this works on a machine where only the lock file was fetched.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

import yaml

from src.churn.config import project_root

LOCK_FILENAME = "dvc.lock"


def read_lock(root: Path | None = None) -> dict[str, Any]:
    """Parse ``dvc.lock``. Returns ``{}`` if the pipeline has never run."""
    path = (root or project_root()) / LOCK_FILENAME
    if not path.exists():
        return {}
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def output_hashes(root: Path | None = None) -> dict[str, str]:
    """Map each stage output path to its DVC content hash.

    ``{"data/processed": "a1b2...dir", "data/interim/features.parquet": "c3d4..."}``
    """
    lock = read_lock(root)
    hashes: dict[str, str] = {}
    for stage in (lock.get("stages") or {}).values():
        for out in stage.get("outs", []) or []:
            digest = out.get("md5") or out.get("hash") or out.get("checksum")
            if out.get("path") and digest:
                hashes[out["path"]] = str(digest)
    return hashes


def git_commit(root: Path | None = None) -> str:
    """Current git commit, with a ``-dirty`` suffix if the tree has changes."""
    cwd = str(root or project_root())
    try:
        sha = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        dirty = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        return f"{sha}-dirty" if dirty else sha
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "unknown"


def lineage_tags(root: Path | None = None) -> dict[str, str]:
    """MLflow tags that pin a run to an exact dataset revision.

    Attach these to every run. Without them an MLflow metric is a number with no
    provenance.
    """
    root = root or project_root()
    tags = {
        "git_commit": git_commit(root),
        # Space-separated: these tags are also set on model versions, which SageMaker
        # mirrors into its registry, and that only allows alphanumerics and " _.:/=+-@".
        "dvc_pipeline_stages": " ".join(sorted((read_lock(root).get("stages") or {}).keys())),
    }
    for path, digest in output_hashes(root).items():
        # mlflow tag keys allow alphanumerics, _-./ and spaces; path separators
        # are fine but we normalise for readability in the UI.
        key = "dvc." + path.replace("/", ".")
        tags[key] = digest
    return tags


def describe(root: Path | None = None) -> str:
    """One-line human summary, for notebook output."""
    tags = lineage_tags(root)
    data_hashes = {k: v for k, v in tags.items() if k.startswith("dvc.")}
    if not data_hashes:
        return f"git {tags['git_commit']} / no dvc.lock yet (run `dvc repro`)"
    parts = ", ".join(f"{k.removeprefix('dvc.')}={v[:8]}" for k, v in sorted(data_hashes.items()))
    return f"git {tags['git_commit'][:12]} / {parts}"
