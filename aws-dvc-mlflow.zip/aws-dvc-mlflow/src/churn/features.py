"""DVC stage 1: raw extract -> model-ready feature table.

Pure pandas, no AWS, no MLflow. That is the point: this stage must be runnable
and reproducible on any machine with the repo checked out, so DVC can hash it
honestly.

Note what this stage does NOT do: it does not balance classes. Resampling
belongs after the split (see :mod:`churn.split`).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd

from churn.config import load_params


def select_columns(df: pd.DataFrame, keep_cols: list[str], extra: list[str]) -> pd.DataFrame:
    """Narrow to the configured feature set, keeping label/id columns.

    Missing columns are reported rather than silently dropped -- a renamed
    upstream column should be loud, not invisible.
    """
    wanted = list(dict.fromkeys([*keep_cols, *extra]))
    missing = [c for c in wanted if c not in df.columns]
    if missing:
        raise KeyError(
            f"Columns configured in params.yaml are absent from the input: {missing}. "
            "Either the extract changed or features.keep_cols is stale."
        )
    return df.loc[:, wanted].copy()


def fill_zero(df: pd.DataFrame, cols: list[str]) -> tuple[pd.DataFrame, dict[str, int]]:
    """Fill the std-dev columns, where NaN means 'only one session so no spread'."""
    filled: dict[str, int] = {}
    out = df.copy()
    for col in cols:
        if col not in out.columns:
            continue
        n = int(out[col].isna().sum())
        if n:
            out[col] = out[col].fillna(0)
        filled[col] = n
    return out, filled


def one_hot(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    present = [c for c in cols if c in df.columns]
    if not present:
        return df.copy()
    return pd.get_dummies(df, columns=present, prefix=present, dtype=int)


def build_features(df: pd.DataFrame, params: dict[str, Any]) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Run the full feature build and return the table plus a summary."""
    feat = params["features"]
    target = params["project"]["target_col"]
    id_col = params["project"]["id_col"]

    out = select_columns(df, feat["keep_cols"], extra=[target, id_col])
    out, filled = fill_zero(out, feat.get("fill_zero_cols", []))
    out = one_hot(out, feat.get("one_hot_cols", []))

    # The label arrives as a bool; XGBoost wants 0/1.
    out[target] = out[target].astype("int64")

    remaining = out.isna().sum()
    summary = {
        "n_rows": int(len(out)),
        "n_cols": int(out.shape[1]),
        "nan_filled": filled,
        "columns_with_nan": {k: int(v) for k, v in remaining[remaining > 0].items()},
        "positive_rate": float(out[target].mean()),
    }
    return out, summary


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Build the churn feature table.")
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--params", type=Path, default=None)
    ap.add_argument(
        "--summary",
        type=Path,
        default=Path("reports/features_summary.json"),
        help="Where to write the stage summary JSON.",
    )
    args = ap.parse_args(argv)

    params = load_params(args.params)
    raw = pd.read_csv(args.input)
    features, summary = build_features(raw, params)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    features.to_parquet(args.output, index=False)

    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(
        f"features: {summary['n_rows']} rows x {summary['n_cols']} cols "
        f"(positive rate {summary['positive_rate']:.3f}) -> {args.output}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
