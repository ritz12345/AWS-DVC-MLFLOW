"""Player-churn MLOps pipeline: SageMaker training, MLflow tracking, DVC data versioning."""

__version__ = "0.1.0"
