"""Model artifact helpers and MLflow version-compat shims."""

from __future__ import annotations

import tarfile
import tempfile
from pathlib import Path
from typing import Any

import xgboost as xgb

from churn.aws import download_file


def load_booster(model_data_s3_uri: str, region: str) -> xgb.Booster:
    """Download ``model.tar.gz`` from a training job and load the Booster."""
    with tempfile.TemporaryDirectory() as tmp:
        tmpdir = Path(tmp)
        archive = download_file(model_data_s3_uri, tmpdir / "model.tar.gz", region)
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(path=tmpdir)  # noqa: S202 - artifact we just produced
        candidates = sorted(tmpdir.rglob("xgboost-model")) or sorted(tmpdir.rglob("*.model"))
        if not candidates:
            raise FileNotFoundError(f"No xgboost model file inside {model_data_s3_uri}")
        booster = xgb.Booster()
        booster.load_model(str(candidates[0]))
        return booster


def log_booster(booster: xgb.Booster, artifact_name: str = "model", **kwargs: Any) -> Any:
    """``mlflow.xgboost.log_model`` across MLflow 2.x and 3.x.

    3.x renamed ``artifact_path`` to ``name`` and deprecated the old keyword;
    2.x only accepts the old one. Try new, fall back.
    """
    import mlflow.xgboost

    try:
        return mlflow.xgboost.log_model(booster, name=artifact_name, **kwargs)
    except TypeError:
        return mlflow.xgboost.log_model(booster, artifact_path=artifact_name, **kwargs)


def model_uri_for_run(run_id: str, artifact_name: str = "model") -> str:
    return f"runs:/{run_id}/{artifact_name}"
