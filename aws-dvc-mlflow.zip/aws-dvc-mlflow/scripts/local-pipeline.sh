#!/usr/bin/env bash
# The whole loop, end to end, exactly as CI runs it.
#
#   ./scripts/local-pipeline.sh              # data -> train -> evaluate
#   ./scripts/local-pipeline.sh --register   # ... -> register @candidate
#
# Requires .env (written by notebooks/00-setup.ipynb).
set -euo pipefail

cd "$(dirname "$0")/.."
export CHURN_PROJECT_ROOT="$PWD"

if [[ ! -f .env ]]; then
  echo "error: .env is missing. Run notebooks/00-setup.ipynb first." >&2
  exit 1
fi
set -a && source .env && set +a

echo "==> reproducing the data pipeline"
dvc repro

echo "==> data lineage"
python -c 'from churn.dvc_meta import describe; print(describe())'

echo "==> training"
python -m churn.training --run-name "local-$(date +%Y%m%d-%H%M%S)"

echo "==> evaluating"
python -m churn.evaluation --fail-below-threshold

if [[ "${1:-}" == "--register" ]]; then
  echo "==> registering"
  python -m churn.registry --require-gate --alias candidate
fi

echo "==> done. reports/:"
ls -1 reports/
