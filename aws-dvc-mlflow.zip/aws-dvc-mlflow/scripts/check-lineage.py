#!/usr/bin/env python3
"""Answer "what data is this model trained on?" for a registered model version.

    python scripts/check-lineage.py                 # whatever @production points at
    python scripts/check-lineage.py --alias staging
    python scripts/check-lineage.py --version 3

Prints the git commit and DVC hashes, and the commands to restore that dataset.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("CHURN_PROJECT_ROOT", str(ROOT))

env_file = ROOT / ".env"
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8").strip().splitlines():
        key, _, value = line.partition("=")
        os.environ.setdefault(key, value)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group()
    group.add_argument("--alias", default="production")
    group.add_argument("--version", default=None)
    args = ap.parse_args()

    import mlflow
    from mlflow.tracking import MlflowClient

    from churn.config import Settings, load_params

    params = load_params()
    settings = Settings.load(params, require_role=False)
    if not settings.mlflow_tracking_uri:
        print("MLFLOW_TRACKING_URI is not set (run notebooks/00-setup.ipynb)", file=sys.stderr)
        return 1

    mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
    client = MlflowClient()
    name = params["project"]["registered_model_name"]

    if args.version:
        version = client.get_model_version(name, args.version)
        label = f"v{args.version}"
    else:
        version = client.get_model_version_by_alias(name, args.alias)
        label = f"@{args.alias} (v{version.version})"

    print(f"{name} {label}")
    print(f"  mlflow run : {version.run_id}")

    commit = version.tags.get("git_commit", "?")
    print(f"  git commit : {commit}")
    for key, value in sorted(version.tags.items()):
        if key.startswith("dvc."):
            print(f"  {key:<28} {value}")
    for key in ("test_auc", "gate_passed"):
        if key in version.tags:
            print(f"  {key:<28} {version.tags[key]}")

    if commit.endswith("-dirty"):
        print("\n  WARNING: trained from a dirty tree; the data cannot be restored exactly.")
    elif commit != "?":
        print(f"\n  Restore that dataset:\n    git checkout {commit}\n    dvc checkout")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
