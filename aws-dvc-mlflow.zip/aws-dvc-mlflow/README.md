# churn-mlops

Player-churn classifier on SageMaker, rebuilt on three tools with no overlapping
responsibilities.

| Concern | Tool | Source of truth |
| --- | --- | --- |
| Code | git / GitHub | the commit |
| Data | **DVC** (S3 remote) | `dvc.lock` + `*.dvc` pointers |
| Experiments & models | **SageMaker managed MLflow** | the run / registered model version |
| CI/CD | **GitHub Actions** | `.github/workflows/churn-*.yml` |

This replaces the Feature Store → SageMaker Projects → CodePipeline flow in the
parent repo's `00`–`07` notebooks. Those are left untouched; nothing here
modifies them.

## The join between DVC and MLflow

Neither tool is useful alone. DVC knows which bytes went into a model; MLflow
knows which run produced it. So every MLflow run — and every registered model
version — is tagged with the git commit **and** the DVC content hashes from
`dvc.lock`:

```
git_commit                     4f2a1c9e...
dvc.data.interim.features.parquet   8c1d...
dvc.data.processed                  a93f....dir
test_auc                       0.8412
```

Which makes this possible, for any model version, at any time:

```sh
python scripts/check-lineage.py --alias production
git checkout <git_commit>
dvc checkout            # the exact training data is back
```

An MLflow metric with no dataset pointer is a number you cannot defend. That is
the whole argument for this stack.

## Layout

```
churn-mlops/
├── params.yaml                 every tunable: features, split, hyperparams, gates
├── dvc.yaml                    the data DAG (raw -> features -> splits)
├── dvc.lock                    content hashes, committed  <- the data pointer
├── notebooks/
│   ├── 00-setup.ipynb              env + MLflow server, writes .env once
│   ├── 01-data-versioning.ipynb    dvc init, S3 remote, track the dataset
│   ├── 02-pipeline.ipynb           dvc repro, the leak fix, selective reruns
│   ├── 03-train.ipynb              SageMaker training job, tracked in MLflow
│   ├── 04-evaluate.ipynb           test metrics + the promotion gate
│   ├── 05-register.ipynb           MLflow registry, mirrored to SageMaker
│   ├── 06-deploy.ipynb             endpoints + batch transform
│   ├── 07-github-actions.ipynb     OIDC role, variables, environments
│   └── 99-cleanup.ipynb            remove what bills
├── src/churn/
│   ├── config.py               params.yaml + env vars (no pasted ARNs)
│   ├── features.py             DVC stage 1   (pure pandas)
│   ├── split.py                DVC stage 2   (pure pandas)
│   ├── dvc_meta.py             the DVC <-> MLflow join
│   ├── training.py             SageMaker job + MLflow run
│   ├── evaluation.py           metrics + gate
│   ├── registry.py             MLflow registry + SageMaker mirror
│   ├── deployment.py           alias -> endpoint
│   ├── aws.py                  sessions, MLflow server, S3 staging
│   └── models.py               artifact loading, MLflow 2.x/3.x shims
├── tests/                      17 tests, including the leak regression guard
├── scripts/
│   ├── local-pipeline.sh       the full loop, as CI runs it
│   └── check-lineage.py        "what data is production trained on?"
└── data/                       DVC-managed, gitignored except the pointers

../.github/
├── actions/churn-setup/        install + OIDC + dvc pull (shared)
└── workflows/churn-{ci,train,register,deploy}.yml
```

GitHub only reads workflows from the **repository root**, so `.github/` lives one
level up. Everything else is self-contained here.

## Quick start

```sh
cd churn-mlops
pip install -e . -r requirements-dev.txt
nbstripout --install --attributes .gitattributes   # once per clone
```

The last line registers a git filter that strips cell outputs from notebooks as they
are committed (your local copies keep them). Outputs print the account id, IAM user
and role ARNs, so without it they would end up in git history.

Then run `notebooks/00-setup.ipynb` through `07-github-actions.ipynb` in order.
Notebook 00 writes a `.env` that every later notebook reads — **you never paste
an ARN into a cell.**

Once set up, the whole loop is one command:

```sh
./scripts/local-pipeline.sh --register
```

## The pipeline

```
data/raw/player_churn.csv              (dvc add)
        │  features     select 17 cols -> fill std NaNs -> one-hot -> int label
        ▼
data/interim/features.parquet
        │  split        stratified 70/20/10 -> oversample TRAIN fold only
        ▼
data/processed/{train,validation,test_x,test_y,baseline}.csv
        │  churn.training      SageMaker XGBoost job, MLflow run + lineage tags
        ▼  churn.evaluation    test AUC/AP/P/R/F1, ROC, gate vs params.yaml
        │  churn.registry      MLflow version, @candidate -> @staging
        ▼  churn.deployment    alias -> endpoint (staging / production)
```

`features` and `split` are pure pandas — no AWS, no MLflow. That is what makes
them reproducible anywhere, which is what makes DVC's hashes mean something.

Training and evaluation deliberately stay **out** of the DVC graph. They run as
remote SageMaker jobs and their lineage lives in MLflow, which already stores
params, metrics and the artifact. Making them DVC stages would churn `dvc.lock`
on every experiment and leave you with two competing metric stores.

## A methodological fix

The original workshop oversampled the minority class in notebook 01, ingested the
duplicated rows into Feature Store, and split in notebook 02 — in that order. So
copies of the same player landed in both train and test, and the test fold was
rebalanced to 50/50. Its reported AUC measured partly memorisation, on a
distribution that does not exist.

Here the split comes first and only the train fold is oversampled:

```
train_rows_before_balance   1148
train_rows                  2102      <- oversampled to 50/50
train_positive_rate         0.500
validation_positive_rate    0.082     <- real rate, preserved
test_positive_rate          0.085     <- real rate, preserved
```

**Expect a lower AUC than the workshop reported.** That is the fix working. With
an 8.4% positive rate, read `test_average_precision` alongside AUC —
average precision is far more informative when positives are rare.

`tests/test_split.py::test_no_player_leaks_from_train_into_test` is the
regression guard, and it runs on every PR.

## CI/CD

| Workflow | Trigger | Does |
| --- | --- | --- |
| `churn / ci` | every PR | ruff, pytest, **and** `dvc status` — fails if `dvc.lock` is stale |
| `churn / train` | `train` label on a PR, or manual | `dvc repro` → train → evaluate → metrics commented on the PR |
| `churn / register` | merge to `main` | retrain, enforce the AUC gate, register, `@candidate` + `@staging` |
| `churn / deploy` | manual | deploy `@staging` / `@production`, gated by a GitHub Environment |

Training is **not** automatic on every PR — it costs money, so it needs the
`train` label.

Two things worth calling out:

- **`churn / ci` catches stale data.** If you edit `features.py` but forget to
  re-run the pipeline, the committed `dvc.lock` no longer describes the committed
  code, and CI fails. The original workshop had no equivalent check because
  nothing recorded what the data was.
- **The approval gate is a GitHub Environment.** Add required reviewers to
  `churn-production` and a production deploy pauses until someone approves, with
  the audit trail next to the code review. That replaces both the
  `PendingManualApproval` model status and CodePipeline's manual-approval stage.

Auth is **OIDC** — GitHub mints a short-lived token, AWS exchanges it for
temporary credentials. No access keys in the repo. Notebook 07 creates the role.

### Required repository variables

Set under **Settings → Secrets and variables → Actions → Variables** (notebook 07
prints the `gh` commands):

`AWS_REGION`, `AWS_GHA_ROLE_ARN`, `CHURN_S3_BUCKET`, `CHURN_SAGEMAKER_ROLE`,
`MLFLOW_TRACKING_URI`

None is a credential, so variables rather than secrets — failed runs stay
debuggable.

## Working with the data

```sh
dvc repro                  # rebuild stale stages only
dvc push                   # data to S3   <- always before the commit
dvc status                 # working tree vs dvc.lock
dvc diff HEAD~1            # what data changed between commits
dvc checkout               # restore the data this commit points at
```

The discipline, every time data changes: **`dvc push`, then `git commit`.** A
commit whose pointers reference blobs nobody can fetch is worse than no commit.

## Registry model

MLflow is the source of truth; the SageMaker Model Registry is a mirror, driven
by `AutomaticModelRegistration=True` on the tracking server. You interact only
with MLflow, and Studio's registry UI, model packages and the SageMaker deploy
path keep working.

Two caveats the code handles: the mirror is **asynchronous**
(`wait_for_mirrored_package` polls), and it can be **absent** — so
`churn.deployment` falls back to building the SageMaker model from the training
job's artifact, and the deployment report records which path was used.

Stage is expressed with MLflow **aliases**, not the deprecated stages API:
`@candidate` → `@staging` → `@production`. Promotion moves a pointer; nothing is
rebuilt or copied.

## Cost

Hourly while they exist: the **MLflow tracking server** and any **endpoints**.
Everything else is per-use or per-GB. `notebooks/99-cleanup.ipynb` removes them
with a confirmation per resource.

For batch churn scoring you may not want a live endpoint at all — notebook 06
shows Batch Transform, which costs nothing when idle.

## Not carried over

- **Feature Store.** Replaced by DVC. You lose online single-record lookup, which
  this batch-scoring model never used. If you need it later, the clean split is
  DVC for the training path and Feature Store purely as a serving cache.
- **SageMaker Projects / Service Catalog / CodePipeline / CodeBuild.** Replaced by
  four workflow files.
- **Model Cards.** The workshop auto-generated one at registration. MLflow model
  version tags and description carry the equivalent metadata here; add
  `sagemaker.model_card` back in `churn.registry` if you need the formal artifact
  for governance.
- **The parent repo's Bedrock notebooks** (`08`, `09`). Unrelated to this
  pipeline and left as they are.
